import tkinter as tk
from tkinter import messagebox


window = tk.Tk()

tk.Button(window,text="aaaa").pack()

window.mainloop()
from cryptography import fernet
from cryptography.fernet import Fernet
#generates key 
key = Fernet.generate_key()

print(key)

file = open('key.key','wb')
file.write(key)#stores key
file.close
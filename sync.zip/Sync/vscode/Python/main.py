import tkinter as tk
from tkinter import messagebox


window = tk.Tk()


def kys():
    tk.messagebox.showinfo(title='Khalid', message='AHAHAHA Khalid KYS')

tk.Button(window,text="ahahah kys",command=kys).pack()

window.mainloop()
board = ["-","-","-","-","-","-","-","-","-"]
game_still_going = True
winner = "None"

current_player = "X"
    
def display_board():
        print(board[0]+ "|" + board[1] + "|" + board[2])
        print(board[3]+ "|" + board[4] + "|" + board[5])
        print(board[6]+ "|" + board[7] + "|" + board[8])
        

def handle_turn(current_player):
    
    print(current_player+"'s Turn")
    position = input("choose a position from 1 to 9: ")
    
    
        
        
    while position not in ["1","2","3","4","5","6","7","8","9"]:
         position =  input("Not a valid space try 1-9: ")
        
    position = int (position)-1
    
    if board[position]!= "-":
        print("That space is full try again")
        return
    
    board[position]=current_player
    display_board()
 
 
 
def check_if_win():
    
    global game_still_going
    global winner
    #check rows 
    row_1 = board[0] == board[1] == board[2]!="-"
    row_2 = board[3] == board[4] == board[5]!="-"
    row_3 = board[6] == board[7] == board[8]!="-"
    
    if row_1 or row_2 or row_3 :
        game_still_going = False
        if row_1:
            winner =  board[0]
        if row_2:
            winner =  board[3]
        if row_3:
            winner =  board[6]
    #checkcolumns
    column_1 = board[0] == board[3] == board[6]!="-"
    column_2 = board[1] == board[4] == board[7]!="-"
    column_3 = board[2] == board[5] == board[8]!="-"
    
    if column_1 or column_2 or column_3 :
        game_still_going = False
        if column_1:
            winner =  board[0]
        if column_2:
            winner =  board[4]
        if column_3:
            winner = board[8]
    #check diagonal
    diagonal_1 = board[0] == board[4] == board[8]!="-"
    diagonal_2 = board[2] == board[4] == board[6]!="-"
   
    
    if diagonal_1 or diagonal_2 :
        game_still_going = False
        if diagonal_1:
            winner = board[0]
        if diagonal_2:
            winner =  board[2]

     

def check_if_tie():
    
    
    global board
    global game_still_going
    
    if "-"  not in board:
        game_still_going = False
    return

def flip_player():
    
    global current_player
    
    if current_player == "x" or current_player == "X":
        current_player="O"
    elif current_player == "o" or current_player == "O":
        current_player="X"
    

    
    
def check_if_game_over():
    
    check_if_win()
    check_if_tie()  
    
def play_game():
    display_board()
    while game_still_going:
        
        handle_turn(current_player)
        
        check_if_game_over()
        
        flip_player()    
    
    if winner== "X" or winner=="O":
        print(winner+" Won")
     
    elif winner == "None":
        print("It's a tie")
        
    
    
play_game()
        









#board
#display board
#play game
#handle turn
#chack win
    #check v
    #check h
    #chack d
#chek tie
#sx
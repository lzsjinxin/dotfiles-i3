CREATE database gestcomm
use gestcomm

create TABLE client(codecl INT,
                    nom VARCHAR(30),
                    ville VARCHAR(30),
                    primary key (codecl) )

create table commande(numcom int,
                      datecom date,
                      codecl INT FOREIGN KEY REFERENCES client(codecl),
                      PRIMARY KEY (numcom) )

CREATE TABLE article (codeart int,
                      designation VARCHAR(30),
                      pu money,
                      qstock int,   
                      primary key (codeart))

CREATE TABLE detail (numcom int FOREIGN key REFERENCES commande(numcom),
                     codeart int FOREIGN key REFERENCES article(codeart),
                     qte int,
                     primary key(numcom,codeart))

--client insert 

insert into client VALUES(1,'Touihri','Casa')

insert into client VALUES(2,'Ayeb','Marrakech')

insert into client VALUES(3,'Afaas','Laarach')

--commande insert

INSERT into commande VALUES(1,'20210126',1)

INSERT into commande VALUES(2,'20200611',2)

INSERT into commande VALUES(3,'20190303',3)

--article insert

INSERT into article VALUES(1,'Arcade Ahri',1350,35)

INSERT into article VALUES(2,'Foxfire Ahri',975,107)

INSERT into article VALUES(3,'Star Guardian Ahri',1820,16)



--detail insert

insert into detail VALUES(1,1,1)

insert into detail VALUES(2,2,1)

insert into detail VALUES(3,3,1)

insert into detail VALUE(num comm ,@article_num,@quantite)


SELECT * FROM client
SELECT * FROM commande
SELECT * FROM article
SELECT * FROM detail

GO
CREATE PROCEDURE Getqtepu
AS
BEGIN
SELECT a.codeart AS 'Code Article' , designation, pu,qte AS 'Quantité' ,pu*qte AS 'Montant',qstock FROM article a,detail d WHERE d.codeart=a.codeart  
END
TRUNCATE TABLE detail

TRUNCATE TABLE Article

DROP PROCEDURE Getqtepu


GO
CREATE PROCEDURE chkqt @quantite int,  @article_num INT
AS
BEGIN
DECLARE @qstock int 
SELECT * FROM article 
SET @qstock = (SELECT qstock FROM article WHERE codeart = @article_num )
if(@quantite > @qstock)
BEGIN
RAISERROR('Stock insuffisant',15,1)
END
END

DROP PROCEDURE chkqt

UPDATE article SET qstock = 20 WHERE codeart = 3


SELECT * FROM article

GO
CREATE PROCEDURE 
AS
BEGIN
SELECT a.codeart AS 'Code Article' , designation, pu,qte AS 'Quantité' ,pu*qte AS 'Montant' FROM article a,detail d WHERE d.codeart=a.codeart  
END
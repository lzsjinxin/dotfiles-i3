CREATE DATABASE efm
use efm

create table theme(code_th int IDENTITY(1,1) ,
                   nom_th varchar(30),
                   description_th varchar(200),
                   primary key (code_th))

CREATE TABLE membre(login varchar(30),
                    nom varchar(20),
                    prenom VARCHAR(20),
                    email varchar(50) CHECK(email LIKE '%@%'),
                    passe varchar(100),
                    primary key (login))


create table ideedeco(code_id int IDENTITY(1,1),
                      description_id varchar(200),
                      date_envoi datetime,
                      code_th  INT foreign key references theme(code_th),
                      login VARCHAR(30) foreign key references membre(login),
                      primary key (code_id))


CREATE TABLE commentaire (code_commentaire int,
                          date_commentaire datetime,
                          texte_commentaire varchar(400),
                          code_id int FOREIGN key references ideedeco(code_id),
                          login VARCHAR(30) foreign key references membre(login),
                          primary key (code_commentaire))

DROP TABLE commentaire
INSERT into membre VALUES('lzs_jinxin','Touihri','Adam','adamtouihri@gmail.com','password1')
INSERT into membre VALUES('somo19','Souri','Moncef','moncefsouri@gmail.com','password2')
INSERT into membre VALUES('Mugiwara9','Maha','Hamza','mahahamza@gmail.com','password3')


INSERT into theme VALUES (1,'Vivalto Lungo','un genre de theme qui est pour votre cuisine qui rasemble un café doux et moelleux')
INSERT into theme VALUES (2,'Dolcao De Brazil','un théme pour le salon qui provoque la sensation et le besoin d allez a la celle')
INSERT into theme VALUES (3,'Romanes eunt Domnus','ce theme de jardin exquisite donne limpression detre dans lancienne rome avec du ceramique plutot agreable')


INSERT into ideedeco VALUES(1,'Vialto Lungo idee','20200614',1,'lzs_jinxin')
INSERT into ideedeco VALUES(2,'Dolcao De Brazil idee','20200712',2,'somo19')
INSERT into ideedeco VALUES(3,'Romanes eunt Domus idee','20210215',3,'Mugiwara9')


insert into commentaire VALUES(1,'20210213','this is very god design',1,'lzs_jinxin')
insert into commentaire VALUES(2,'20210214','Loituma Polka loitum ipsum',2,'somo19')
insert into commentaire VALUES(3,'20210215','Is this a monty python reference??!!',3,'Mugiwara9')

select * FROM membre

select * FROM theme

select * FROM ideedeco

select * FROM commentaire



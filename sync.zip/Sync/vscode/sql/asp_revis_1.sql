create database deal
use deal

CREATE TABLE client (
    Email varchar(30) ,
    prenom varchar(30),
    nom varchar(30),
    telephone int ,
    adresse varchar(100),
    ville varchar(20),
    date_naissance date ,
    passwordd VARCHAR(30),
    PRIMARY KEY(email)
)
CREATE TABLE cartebanquaire(
    numcartebanquaire int ,
    code int ,
    email VARCHAR(30) FOREIGN KEY REFERENCES client(Email)
    primary key(numcartebanquaire)
)

INSERT into client values ('a@gmail.com','adam','touihri',0622334455,'10 rue mohammed 5','Casablanca','2001-06-21','a')
insert into cartebanquaire VALUES(1,2021,'a@gmail.com')

select * from client 
select * FROM cartebanquaire


CREATE DATABASE efm_BD

use efm_BD

CREATE TABLE cours (numcours int primary key,
                    numsalle int ,
                    matriculeprofesseur int foreign key REFERENCES professeur(matriculeprofesseur),
                    titre varchar(30),
                    coef INT  )

create table etudiant (codeetudiant int primary key ,
                       nom varchar(30),
                       Prenom varchar(30),
                       date_naiss datetime)

CREATE TABLE professeur (matriculeprofesseur int primary key,
                         Nom varchar(30),
                         Prenom varchar(30),
                         )

CREATE TABLE examen (codeetudiant int foreign key REFERENCES etudiant(codeetudiant),
                     numcours int foreign key REFERENCES cours(numcours),
                     Dates DATE,
                         float,
                      primary key(codeetudiant,numcours))

INSERT into etudiant VALUES(1,'E nom 1','E prenom 1','2001-06-21')
INSERT into etudiant VALUES(2,'E nom 2','E prenom 2','2003-07-14')
INSERT into etudiant VALUES(3,'E nom 3','E prenom 3','1999-12-5')

INSERT into professeur VALUES(1,'P nom 1','P prenom 1')
INSERT into professeur VALUES(2,'P nom 2','P prenom 2')
INSERT into professeur VALUES(3,'P nom 3','P prenom 3')

INSERT into examen VALUES(1,1,'2020-06-21',14)
INSERT into examen VALUES(2,2,'2021-03-01',15)
INSERT into examen VALUES(3,3,'2021-03-02',16)

INSERT into cours VALUES(1,14,1,'ADO',3)
INSERT into cours VALUES(2,13,2,'UML',2)
INSERT into cours VALUES(3,17,3,'POO',3)

    select * FROM etudiant
    SELECT * FROM professeur
    SELECT * FROM examen
    SELECT * FROM cours

       select * FROM etudiant WHERE codeetudiant= 1 ,nom = 'E1',prenom = 'e prenom 1'


       
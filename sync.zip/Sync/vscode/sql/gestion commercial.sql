create DATABASE gestion_comm
USE gestcomm

create TABLE client(codecl INT,
                    nom VARCHAR(30),
                    ville VARCHAR(30),
                    primary key (codecl) )

create table commande(numcom int,
                      datecom date,
                      codecl INT FOREIGN KEY REFERENCES client(codecl),
                      PRIMARY KEY (numcom) )

CREATE TABLE article (codeart int,
                      designation VARCHAR(30),
                      pu money,
                      qstock int,   
                      primary key (codeart))

CREATE TABLE detail (numcom int FOREIGN key REFERENCES commande(numcom),
                     codeart int FOREIGN key REFERENCES article(codeart),
                     qte int,
                     primary key(numcom,codeart))

--client insert 

insert into client VALUES(1,'Touihri','Casa')

insert into client VALUES(2,'Ayeb','Marrakech')

insert into client VALUES(3,'Afaas','Laarach')

--commande insert

INSERT into commande VALUES(1,'20210126',1)

INSERT into commande VALUES(2,'20200611',2)

INSERT into commande VALUES(3,'20190303',3)

--article insert

INSERT into article VALUES(1,'Arcade Ahri',1350,35)

INSERT into article VALUES(2,'Foxfire Ahri',975,107)

INSERT into article VALUES(3,'Star Guardian Ahri',1820,16)



--detail insert

insert into detail VALUES(1,1,1)

insert into detail VALUES(2,2,1)

insert into detail VALUES(3,3,1)


SELECT * FROM client
SELECT * FROM commande
SELECT * FROM article
SELECT * FROM detail

GO
CREATE PROCEDURE Getqtepu
AS
BEGIN
SELECT a.codeart AS 'Code Article' , designation, pu,qte AS 'Quantité' ,pu*qte AS 'Montant' FROM article a,detail d WHERE d.codeart=a.codeart  
END
TRUNCATE TABLE detail

TRUNCATE TABLE Article

DROP PROCEDURE GEtqtepu



GO
CREATE PROCEDURE mnt @qnt int , @id int 
AS
BEGIN
SELECT @qnt * pu AS 'montant'  FROM Article WHERE codeart = @id
END
DROP PROCEDURE mnt

mnt @qnt=12,@id=3

DELETE from article

TRUNCATE TABLE detail


SELECT a.codeart AS 'Code Article' , designation, pu,qte AS 'Quantité' ,pu*qte AS 'Montant',qstock,c.numcom,datecom FROM article a,detail d,commande c WHERE d.codeart=a.codeart AND c.numcom = d.numcom


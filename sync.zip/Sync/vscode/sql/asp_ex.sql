create DATABASE asp_ex
go
use asp_ex
GO

create table membre (
    loginn varchar(30),
    pass VARCHAR(30),
    nom VARCHAR(30),
    mail VARCHAR(30),
    date_naissance varchar(30),
    PRIMARY KEY(loginn)
)
CREATE TABLE モロッコ (
король NVARCHAR(35) PRIMARY KEY,
πρίγκιπας NVARCHAR(35),
รายได้สุทธิ int ,
نوع NVARCHAR(35),
وريث VARCHAR(35)

)

DROP TABLE モロッコ

INSERT INTO モロッコ VALUES('dffoj','fdjosd',54644545,'العلويون','الحسن الثالث')
INSERT INTO モロッコ VALUES('dqsdqs','fdjosd',54644545,N'العلويون',N'الحسن الثالث')
INSERT INTO モロッコ VALUES('ddfgdf','fdjosd',54644545,N'العلويون',N'الحسن الثالث')
INSERT INTO モロッコ VALUES('ddfgdf','fdjosd',54644545,N'العلويون',N'الحسن الثالث')
SELECT * from モロッコ 

INSERT INTO membre VALUES('a','a','a','a@gmail.com','2001-05-06') , ('b','b','b','b@gmail.com','2001-06-30')
SELECT * FROM membre
select * from membre where nom = 'a'

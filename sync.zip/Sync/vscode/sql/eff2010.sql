create database EFF2010_TP_V01
use EFF2010_TP_V01

create table Specialite(
IdSpecialite int primary key,
libelle varchar(30)
)
create table Patient(
IdPatient int primary key,
Nom varchar(30),
Prenom varchar(30),
DdN varchar(30),
Sexe varchar(30),
Adresse varchar(50)
)
    create table Hopital(
IdHopital int primary key,
Nom varchar(30),
Adresse varchar(30),
Ville varchar(30)
)   
create table Servicee(
IdService int primary key,
IdHospital int foreign key references Hopital(IdHopital),
NBLits varchar(30)
)
create table Sejourne(
    IdSejour int primary key,
    IdService int foreign key references Servicee(IdService),
    IdPatient int foreign key references Patient(IdPatient),
    DateEntree date,
    DateSortie date
)
create table Medecin(
IdMedecin int primary key,
Nom varchar(30),
Prenom varchar(30),
DdN varchar(30),
Sexe varchar(30),
IdSpecialite int foreign key references Specialite(IdSpecialite),
IdService int foreign key references Servicee(IdService)
)
create table Soigne(
IdSoin int primary key,
IdMedecin int foreign key references Medecin(IdMedecin),
IdPatient int foreign key references Patient(IdPatient),
nommaladie varchar(30),
Commentare varchar(30),
Date_soigne date
)
    SELECT * FROM Specialite
    SELECT * FROM Patient
    SELECT * FROM Hopital
    SELECT * FROM Servicee
    SELECT * FROM Sejourne
    SELECT * FROM Medecin
    SELECT * FROM Soigne

INSERT INTO Specialite VALUES (1,'L1')
INSERT INTO Specialite VALUES (2,'L2')

INSERT INTO Patient VALUES (1,'pN1','pP1','2011-06-01','M','pAdresse1')
INSERT INTO Patient VALUES (2,'pN2','pP2','2011-06-02','F','pAdresse2')

INSERT INTO Hopital VALUES (1,'hN1','hAdresse1','hV1')
INSERT INTO Hopital VALUES (2,'hN2','hAdresse2','hV2')

INSERT INTO Servicee VALUES (1,1,20)
INSERT INTO Servicee VALUES (2,2,40)

INSERT INTO Sejourne VALUES (1,1,1,'2018-02-17','2020-09-10')
INSERT INTO Sejourne VALUES (2,2,2,'2016-08-11','2017-01-16')

INSERT INTO Medecin VALUES (1,'House','Gregory','DDN1','M',1,1)
INSERT INTO Medecin VALUES (2,'Cameron','Alyson','DDN2','F',2,2)

INSERT INTO Soigne VALUES (1,1,1,'Lupus','its never lupus','2021-02-23')
INSERT INTO Soigne VALUES (2,2,2,'Sirtus Inversus','Sheer heart attack','2021-02-20')


SELECT * FROM



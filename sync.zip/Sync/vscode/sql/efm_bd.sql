CREATE DATABASE efm_db

use efm_db

CREATE TABLE magasin (numero_magasin int primary key,
                      libelle_magasin varchar(30),
                      date_creation date,
                      tel int,
                      adresse varchar(100),
                      ville varchar(30),)

create table motifsrejet(code_motif int primary key ,
                         libelle_motif varchar(100),
                         )

CREATE TABLE banque(code_banque int primary key,
                    libelle_banque varchar(100),
                    adresse_siege varchar(100),
                    tel int ,
                    ville varchar(30))

CREATE TABLE client ( cin varchar(15) primary key,
                      genre varchar(30),
                      nom varchar(30),
                      prenom varchar(30),
                      tel int ,
                      adresse VARCHAR(100),
                      ville varchar(30),
                      numero_magasin int foreign key REFERENCES magasin(numero_magasin) on update cascade on delete cascade,)

CREATE TABLE cheque (numero_cheque int primary key,
                     date_emmission date,
                     montant FLOAT,
                     url_cheque VARCHAR(30),
                     code_motif int foreign key REFERENCES motifsrejet(code_motif)on update cascade on delete cascade,
                     cin varchar(15) foreign key REFERENCES client(cin) on update cascade on delete cascade,
                     code_banque int foreign key REFERENCES banque(code_banque) on update cascade on delete cascade,
                     numero_magasin int foreign key REFERENCES magasin(numero_magasin))

INSERT into magasin VALUES(1,'magasin1','20200111',0511108613,'Adresse mag 1','casa')
INSERT into magasin VALUES(2,'magasin2','20200222',0522208613,'Adresse mag 1','casa')
INSERT into magasin VALUES(3,'magasin3','20200303',0533308613,'Adresse mag 1','casa')

INSERT into motifsrejet VALUES(1,'motif1')
INSERT into motifsrejet VALUES(2,'motif2')
INSERT into motifsrejet VALUES(3,'motif3')

INSERT into banque VALUES(1,'banque1','Adresse siege 1',0534551322,'Casa')
INSERT into banque VALUES(2,'banque2','Adresse siege 2',0524847382,'Casa')
INSERT into banque VALUES(3,'banque3','Adresse siege 3',0536273362,'Casa')

INSERT into client VALUES('BE907145','genre 1','nom 1','prenom 1',0644504388,'Adresse client 1','Casa',1)
INSERT into client VALUES('BE908146','genre 2','nom 2','prenom 2',0632323243,'Adresse client 2','Casa',2)
INSERT into client VALUES('BE909147','genre 3','nom 3','prenom 3',0623847238,'Adresse client 3','Casa',3)

INSERT into cheque values(1,'20210302',5000,'url1',1,'BE907145',1,1)
INSERT into cheque values(2,'20210304',5000,'url2',2,'BE908146',2,2)
INSERT into cheque values(3,'20210301',5000,'url3',3,'BE909147',3,3)

select * FROM client
select * FROM magasin
select * FROM cheque
select * FROM motifsrejet
select * FROM banque


SELECT * FROM cheque WHERE code_motif = 1 and numero_magasin = 1 ORDER BY date_emmission


select c.numero_cheque,date_emmission,montant,r.libelle_motif,m.libelle_magasin from cheque c, magasin m , motifsrejet r, client l  WHERE c.cin = l.cin and m.numero_magasin= c.numero_magasin and r.code_motif = c.code_m

create database emprunt 

use emprunt

CREATE TABLE emprunt(
    
)
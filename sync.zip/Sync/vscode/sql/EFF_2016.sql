-- Creation de db et tables
create DATABASE eff_2016
GO
use eff_2016
GO

CREATE TABLE categorie(
    idcategorie int PRIMARY KEY,
    nomcategorie VARCHAR(50)
)
go
CREATE TABLE organisateur (
    idorg int primary KEY,
    nomorg VARCHAR(30),
    prenomorg VARCHAR(30),
    emailorg VARCHAR(30),
    passorg VARCHAR(128)
)
GO
CREATE TABLE campagne(
    idcamp int primary key ,
    nomcamp varchar(30),
    descriptionn VARCHAR(512),
    datecreation DATE,
    datefin int,
    montantcamp FLOAT, 
    nombeneficiaire VARCHAR(30),
    prebeneficiaire VARCHAR(30),
    datedernierepart date,
    idcategorie int FOREIGN KEY REFERENCES categorie(idcategorie),
    idorg int FOREIGN KEY REFERENCES organisateur(idorg)
)
GO
CREATE TABLE participant(
    idp int primary KEY,
    nomp varchar(30),
    prenomp varchar(30),
    emailp varchar(64),
    passp varchar(128),
)
go
CREATE TABLE participation(
    idpart int primary key IDENTITY(1,1) ,
    datepartt date,
    montantpart FLOAT,
    idcamp int FOREIGN KEY REFERENCES campagne(idcamp),
    idp int FOREIGN KEY REFERENCES participant(idp)

)
go
--insertion des données
insert into categorie VALUES(1,'Categorie 1'),(2,'Categorie 2'),(3,'Categorie 3')
go 
insert into organisateur VALUES(1,'Nomorg 1','Prenomorg 1','Emailorg 1','Passorg1'),(2,'Nomorg 2','Prenomorg 2','Emailorg 2','Passorg2'),(3,'Nomorg 3','Prenomorg 3','Emailorg 3','Passorg3')
GO
INSERT into campagne VALUES(1,'nocamp 1 ','desc 1 ','20210508','20210509',5000,'nomben 1','preben 1','20210512',1,1),(2,'nocamp 2 ','desc 2 ','20210509','20210510',6000,'nomben 2','preben 2','20210511',2,2),(3,'nocamp 3 ','desc 3 ','20210510','20210511',7000,'nomben 3','preben 3','20210514',3,3), (4,'nocamp 4 ','desc 4 ','20150510','20210511',7000,'nomben 4','preben 4','20210514',3,3)
go
INSERT INTO participant VALUES(1,'nomp1','prenomp1','emailp1','passp1'),(2,'nomp 2','prenomp 2','emailp 2','passp2'),(3,'nomp 3','prenomp 3','emailp 3','passp3')
GO
insert into participation VALUES('20210508',5000,1,1),('20210509',6000,2,2),('20210510',7000,3,3)
go
--check les données
select * from categorie
select * from organisateur
select * from campagne
select * from participant
select * from participation order by idpart

DROP TABLE campagne;
-- Requetes demandés
    -- 2
    select COUNT( * ) as 'Nombre de Participants ', nomCamp from Participant, Campagne
    where idP in(select idP from Participation where idCamp in(select idCamp from Campagne))
    group by nomCamp
-   --3
        GO
        CREATE PROCEDURE q3 (@idcamp int)
        AS
        BEGIN
        SELECT SUM(p.montantpart),a.nomp FROM participation p ,participant a WHERE p.idp = a.idp and datepart(year,p.datepartt)=datepart(YEAR,GETDATE()) and p.idcamp = @idcamp GROUP BY a.nomp
        END

        EXEC q3 2
        

    --4
        go 
        CREATE TRIGGER q4 ON participation FOR INSERT
        AS
        BEGIN
        DECLARE @dt DATE,@id INT
        SELECT @dt=datepartt,@id = idcamp from inserted
        UPDATE campagne SET datedernierepart = @dt WHERE campagne.idcamp = @id
        END 

        INSERT INTO participation VALUES('20220812',10000,1,1)
        SELECT * from campagne

    --5
        GO
        CREATE PROCEDURE q5 (@mont float,@idcamp int , @idp int)
        AS
        BEGIN
        INSERT INTO participation VALUES(GETDATE(),@mont,@idcamp,@idp)
        END

        EXEC q5 11000,3,3
        SELECT * from participation
    --6
        GO
        CREATE FUNCTION q6(@idcategorie int) 
        RETURNS FLOAT
        AS BEGIN
        DECLARE @monttotal FLOAT
        SELECT @monttotal = SUM(montantpart) FROM participation p , campagne c WHERE p.idcamp = c.idcamp and c.idcategorie = @idcategorie
        
        RETURN @monttotal
        END
        GO
        SELECT dbo.q6(1)
        


go
CREATE DATABASE asp_efm
GO
use asp_efm
GO
create table PORTABLE (
NUM_PORTABLE int PRIMARY KEY,
TYPE_PORTABLE varchar(30),
PRIX float
)
go
create table ABONNE (
ID_ABONNE int PRIMARY KEY,
NOM_ABONNE varchar(30),
LOGINN varchar(30),
PASSWORDD varchar(30)
)
go
create table ABONNEMENT (
NUM_PORTABLE int foreign key references PORTABLE(NUM_PORTABLE) ,
ID_ABONNE int foreign key references ABONNE(ID_ABONNE),
ABONNEMENT varchar(30),
NOMBRE_MOIS int,
primary key(NUM_PORTABLE,ID_ABONNE)
)
INSERT INTO PORTABLE VALUES(1,'samsung',1500)
INSERT INTO PORTABLE VALUES(2,'samsung',1600)
INSERT INTO PORTABLE VALUES(3,'Xiaomi',1300)
INSERT INTO ABONNE VALUES(1,'touihri','lzs_jinxin','123456')
INSERT INTO ABONNEMENT VALUES(1,1,'annuel',5)
